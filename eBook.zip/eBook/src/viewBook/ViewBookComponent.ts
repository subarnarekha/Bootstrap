import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { BookService } from './BookService'
import { Book } from './Book';
import { ActivatedRoute,Router, Params } from '@angular/router';

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'src/viewBook/viewBook.html'
})
export class ViewBookComponent implements OnInit{
   books:Book[];
   constructor(@Inject(BookService) private bookService:BookService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
  
  ngOnInit(): void{
    this.books = this.bookService.getBooks();
  }
  navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
