import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';

import { HomeComponent } from './home/HomeComponent';
import { ViewBookComponent } from './viewBook/ViewBookComponent';
import { BookService } from './viewBook/BookService';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

enableProdMode();

@Component({
  selector: 'ebook-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'viewBook',  component: ViewBookComponent },

];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule,HttpModule],
    declarations:[ AppComponent, ViewBookComponent, HomeComponent ],
	providers:[BookService],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);